

function showprice()
{
var btn = document.getElementById("price");
btn.value = ''; // will just add a hidden value
btn.innerHTML = '1,000,000. 00 LKR';
}

